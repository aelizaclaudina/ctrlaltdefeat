﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace SoutheasterPage2
{

    public partial class Form2 : Form
    {
        Thread th;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            using (StreamWriter sw = new StreamWriter("info.txt", append: true))
            {
                foreach (var item in ReportTypes.CheckedItems)
                {
                    string CheckedInput = (item.ToString());
                    string time = (DateTime.Now.ToLongTimeString());
                    //string time = (DateTime.Now.ToString());



                    sw.WriteLine(CheckedInput + " (" + time + ")");
                    sw.WriteLine(ReportBox.Text);
                    sw.WriteLine("\t");

                }

                this.Close();
                th = new Thread(openNewForm1);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();

            }
        }
        private void openNewForm1(object? obj)
        {
            Application.Run(new Form1());
        }

        private void ReportTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = ReportTypes.SelectedIndex;
            int count = ReportTypes.Items.Count;
            for (int i = 0; i < count; i++)
            {
                if (index != i)
                {
                    ReportTypes.SetItemChecked(i, false);
                }
            }
        }

    }
}
