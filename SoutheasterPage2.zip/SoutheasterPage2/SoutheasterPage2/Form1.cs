using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace SoutheasterPage2
{
    public partial class Form1 : Form
    {
        string textFile = @"C:\Users\SarahLewis\Documents\Visual Studio stuff\SoutheasterPage2\SoutheasterPage2\bin\Debug\net8.0-windows\info.txt";
        Thread th;

        public Form1()
        {
            InitializeComponent();
            string TextOutput = File.ReadAllText(textFile);
            label3.Text = TextOutput;
        }

        private void Report_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(openNewForm2);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();



        }

        private void openNewForm2(object? obj)
        {
            Application.Run(new Form2());
        }

        private void Share_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(openNewForm3);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void openNewForm3(object? obj)
        {
            Application.Run(new Form3());
        }

        private void All_Trains_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(openNewForm5);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();

        }
        
        private void openNewForm5(object? obj)
        {
            Application.Run(new Form5());
        }
    }
    }

