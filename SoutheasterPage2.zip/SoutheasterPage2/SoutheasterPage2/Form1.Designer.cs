﻿namespace SoutheasterPage2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Report = new Button();
            All_Trains = new Button();
            panel1 = new Panel();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            Share = new Button();
            panel2 = new Panel();
            label3 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // Report
            // 
            Report.Location = new Point(564, 194);
            Report.Name = "Report";
            Report.Size = new Size(169, 83);
            Report.TabIndex = 0;
            Report.Text = "Report Issue";
            Report.UseVisualStyleBackColor = true;
            Report.Click += Report_Click;
            // 
            // All_Trains
            // 
            All_Trains.Location = new Point(582, 796);
            All_Trains.Name = "All_Trains";
            All_Trains.Size = new Size(169, 55);
            All_Trains.TabIndex = 1;
            All_Trains.Text = "All trains";
            All_Trains.UseVisualStyleBackColor = true;
            All_Trains.Click += All_Trains_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(30, 30, 50);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 135);
            panel1.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(30, 30, 50);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Microsoft Sans Serif", 30F);
            textBox1.ForeColor = Color.FromArgb(0, 175, 255);
            textBox1.Location = new Point(234, 18);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(273, 91);
            textBox1.TabIndex = 4;
            textBox1.Text = "eastern";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 30F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 18);
            label1.Name = "label1";
            label1.Size = new Size(246, 91);
            label1.TabIndex = 3;
            label1.Text = "South";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 25F);
            label2.ForeColor = Color.FromArgb(30, 30, 50);
            label2.Location = new Point(32, 176);
            label2.Name = "label2";
            label2.Size = new Size(232, 89);
            label2.TabIndex = 3;
            label2.Text = "Train 3";
            // 
            // Share
            // 
            Share.Location = new Point(32, 796);
            Share.Name = "Share";
            Share.Size = new Size(150, 55);
            Share.TabIndex = 4;
            Share.Text = "Share";
            Share.UseVisualStyleBackColor = true;
            Share.Click += Share_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label3);
            panel2.Location = new Point(32, 304);
            panel2.Name = "panel2";
            panel2.Size = new Size(719, 486);
            panel2.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 16);
            label3.Name = "label3";
            label3.Size = new Size(19, 32);
            label3.TabIndex = 13;
            label3.Text = ".";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 885);
            Controls.Add(panel2);
            Controls.Add(Share);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(All_Trains);
            Controls.Add(Report);
            Name = "Form1";
            Text = "Train 3";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Report;
        private Button All_Trains;
        private Panel panel1;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private Button Share;
        private Panel panel2;
        private Label label3;
    }
}
